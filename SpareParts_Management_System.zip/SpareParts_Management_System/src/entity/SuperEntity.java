package entity;

public interface SuperEntity {
}
