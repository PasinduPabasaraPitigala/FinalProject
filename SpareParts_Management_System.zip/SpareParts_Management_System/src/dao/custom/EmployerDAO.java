package dao.custom;

import dao.CrudDAO;
import entity.Employer;

public interface EmployerDAO extends CrudDAO<Employer,String> {
}
