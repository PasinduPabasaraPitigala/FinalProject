package dao.custom;

import dao.CrudDAO;
import entity.Supplier;

public interface SupplierDAO extends CrudDAO<Supplier,String> {
}
