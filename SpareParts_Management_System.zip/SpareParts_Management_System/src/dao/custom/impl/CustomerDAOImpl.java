package dao.custom.impl;

import dao.custom.CustomerDAO;
import dao.exception.CViolationException;
import dao.util.DBUtil;
import entity.Attendance;
import entity.Customer;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class CustomerDAOImpl implements CustomerDAO {

    private final Connection connection;

    public CustomerDAOImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public Customer save(Customer customer) throws CViolationException, ClassNotFoundException {
        try {
            if (DBUtil.executeUpdate("INSERT INTO Customer (Cid,CName,Address,Tel_Number,Email) VALUES (?,?,?,?,?)",
                    customer.getCid(),customer.getCName(),customer.getAddress(),customer.getTel_Number(),customer.getEmail())){
                return customer;
            }
            throw new SQLException("Failed to save Customer");
        }catch (SQLException e){
            throw new CViolationException(e);
        }
    }

    @Override
    public Customer update(Customer customer) throws CViolationException, ClassNotFoundException {
        try {
            if (DBUtil.executeUpdate("UPDATE Customer SET CName=? ,Address=? ,Tel_Number=? ,Email=? WHERE Cid=?",
                    customer.getCName(),customer.getAddress(),customer.getTel_Number(),customer.getEmail(),customer.getCid())){
                return customer;
            }
            throw new SQLException("Failed to update the customer");
        }catch (SQLException e){
            throw new CViolationException(e);
        }
    }

    @Override
    public void deleteByPk(String Cid) throws CViolationException, ClassNotFoundException {
        try {
            if (DBUtil.executeUpdate("DELETE FROM Attendance WHERE Cid=?",Cid))
            throw new SQLException("Failed to update the customer");
        }catch (SQLException e){
            throw new CViolationException(e);
        }
    }

    @Override
    public List<Customer> findAll() throws ClassNotFoundException {
        try {
            ResultSet rst = DBUtil.executeQuery("SELECT * FROM Customer");
            return getCustomerList(rst);
        }catch (SQLException e){
            throw new RuntimeException("Failed to load the Customer");
        }    }

    private List<Customer> getCustomerList(ResultSet rst) {
        try {
            List<Customer> customerList= new ArrayList<>();
            while (rst.next()){
                Customer customer = new Customer(rst.getString("Cid"),rst.getString("CName"),rst.getString("Address"),rst.getString("Tel_Number"),rst.getString("EmaIL"));
                customerList.add(customer);
            }
            return customerList;
        }catch (SQLException e){
            throw new RuntimeException(e);
        }
    }

    @Override
    public Optional<Customer> findByPk(String pk) throws ClassNotFoundException {
        try{
            ResultSet rst = DBUtil.executeQuery("SELECT * FROM Customer WHERE Cid=?",pk);
            if (rst.next()) {
                return Optional.of(new Customer(rst.getString("Cid"), rst.getString("CName"), rst.getString("Address"), rst.getString("Tel_Number"), rst.getString("Email")));

            }
            return Optional.empty();

        }catch (SQLException e){
            throw new RuntimeException("Failed to find the Customer");
        }
    }

    @Override
    public boolean existByPk(String pk) {
        return false;
    }

    @Override
    public long count() throws ClassNotFoundException {
        try{
            ResultSet rst = DBUtil.executeQuery("SELECT COUNT(Cid) AS count FROM Customer");
            rst.next();
            return rst.getInt(1);
        }catch (SQLException e){
            throw new RuntimeException(e);
        }
    }
}
