package dao.custom.impl;

import dao.custom.ItemDAO;
import dao.exception.CViolationException;
import dao.util.DBUtil;
import entity.Employer;
import entity.Item;
import org.hibernate.exception.ConstraintViolationException;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ItemDAOImpl implements ItemDAO {
    private final Connection connection;

    public ItemDAOImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public Item save(Item item) throws CViolationException, ClassNotFoundException {
        try {
            if(DBUtil.executeUpdate("INSERT INTO Item (Iid,ICategory,IName,IDescription,QTY,Price) VALUES (?,?,?,?,?,?)",
                    item.getIid(),item.getICategory(),item.getIName(),item.getIDescription(),item.getQTY(),item.getPrice())){
                return item;
            }
            throw new SQLException("Failed to save the item");
        }catch (SQLException e){
            throw new CViolationException(e);
        }
    }

    @Override
    public Item update(Item item) throws CViolationException, ClassNotFoundException {
        try {
            if(DBUtil.executeUpdate("UPDATE Item SET ICategory=? ,IName=? ,IDescription=? ,QTY=? ,Price=? WHERE Iid=?",item.getICategory(),item.getIName(),item.getIDescription(),item.getQTY(),item.getPrice())){
                return item;
            }
            throw new SQLException("Failed to update the item");
        } catch (SQLException e) {
            throw new CViolationException(e);
        }
    }

    @Override
    public void deleteByPk(String Iid) throws CViolationException, ClassNotFoundException {
        try {
            if(!DBUtil.executeUpdate("DELETE FROM item WHERE Iid=?",Iid)) throw new SQLException("Failed to delete the item");
        } catch (SQLException e) {
            throw new CViolationException(e);
        }
    }

    @Override
    public List<Item> findAll() throws ClassNotFoundException {
        try{
            ResultSet rst = DBUtil.executeQuery("SELECT * FROM item");
            return getItemList(rst);
        } catch (SQLException e) {
            throw new RuntimeException("Failed to load the item");
        }
    }

    private List<Item> getItemList(ResultSet rst) {
        try {
            List<Item> itemList = new ArrayList<>();
            while (rst.next()){
                Item item = new Item(rst.getString("Iid"), rst.getString("ICategory"), rst.getString("IName"), rst.getString("IDescription"), rst.getString("QTY"),rst.getDouble("Price"));
                itemList.add(item);
            }
            return itemList;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Optional<Item> findByPk(String pk) throws ClassNotFoundException {
        try{
            ResultSet rst = DBUtil.executeQuery("SELECT * FROM Item WHERE Iid=?", pk);
            if(rst.next()){
                return Optional.of(new Item(rst.getString("Iid"), rst.getString("ICategory"), rst.getString("IName"), rst.getString("IDescription"), rst.getString("QTY"),rst.getDouble("Price")));
            }
            return Optional.empty();
        } catch (SQLException e) {
            throw new RuntimeException("Failed to find the item details");
        }
    }

    @Override
    public boolean existByPk(String pk) {
        return false;
    }

    @Override
    public long count() throws ClassNotFoundException {
        try{
            ResultSet rst = DBUtil.executeQuery("SELECT COUNT(Iid) AS count FROM Item");
            rst.next();
            return rst.getInt(1);
        }catch (SQLException e){
            throw new RuntimeException(e);
        }
    }
}
