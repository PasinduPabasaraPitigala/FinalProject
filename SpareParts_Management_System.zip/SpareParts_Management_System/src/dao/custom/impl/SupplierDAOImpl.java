package dao.custom.impl;

import dao.custom.SupplierDAO;
import dao.exception.CViolationException;
import entity.Supplier;
import org.hibernate.exception.ConstraintViolationException;

import java.util.List;
import java.util.Optional;

public class SupplierDAOImpl implements SupplierDAO {
    @Override
    public Supplier save(Supplier entity) throws CViolationException {
        return null;
    }

    @Override
    public Supplier update(Supplier entity) throws CViolationException {
        return null;
    }

    @Override
    public void deleteByPk(String pk) throws CViolationException {

    }

    @Override
    public List<Supplier> findAll() {
        return null;
    }

    @Override
    public Optional<Supplier> findByPk(String pk) {
        return Optional.empty();
    }

    @Override
    public boolean existByPk(String pk) {
        return false;
    }

    @Override
    public long count() {
        return 0;
    }
}
