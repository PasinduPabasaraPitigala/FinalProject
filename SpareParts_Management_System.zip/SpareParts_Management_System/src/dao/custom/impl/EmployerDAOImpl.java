package dao.custom.impl;

import dao.custom.EmployerDAO;
import dao.exception.CViolationException;
import dao.util.DBUtil;
import entity.Employer;
import org.hibernate.exception.ConstraintViolationException;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class EmployerDAOImpl implements EmployerDAO {

    private final Connection connection;

    public EmployerDAOImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public Employer save(Employer employer) throws CViolationException, ClassNotFoundException {
        try {
            if(DBUtil.executeUpdate("INSERT INTO Employer (Eid, EName, EAddress,Email,Tel_Number,jobRole) VALUES (?,?,?,?,?,?)",
                    employer.getEid(),employer.getEName(),employer.getEAddress(),employer.getEmail(),employer.getTel_Number(),employer.getJobRole())){
                return employer;
            }
            throw new SQLException("Failed to save the employer");
        }catch (SQLException e){
            throw new CViolationException(e);
        }
    }

    @Override
    public Employer update(Employer employer) throws CViolationException, ClassNotFoundException {
        try {
            if(DBUtil.executeUpdate("UPDATE Employer SET EName=? ,EAddress=? ,Email=? ,Tel_Number=? WHERE Eid=?",employer.getEName(),employer.getEAddress(),employer.getEmail(),employer.getTel_Number(),employer.getJobRole())){
                return employer;
            }
            throw new SQLException("Failed to update the employer");
        } catch (SQLException e) {
            throw new CViolationException(e);
        }
    }

    @Override
    public void deleteByPk(String Eid) throws CViolationException, ClassNotFoundException {
        try {
            if(!DBUtil.executeUpdate("DELETE FROM employer WHERE Eid=?",Eid)) throw new SQLException("Failed to delete the employer");
        } catch (SQLException e) {
            throw new CViolationException(e);
        }
    }

    @Override
    public List<Employer> findAll() throws ClassNotFoundException {
        try{
            ResultSet rst = DBUtil.executeQuery("SELECT * FROM employer");
            return getEmployerList(rst);
        } catch (SQLException e) {
            throw new RuntimeException("Failed to load the employer");
        }
    }

    private List<Employer> getEmployerList(ResultSet rst) {
        try {
            List<Employer> employerList= new ArrayList<>();
            while (rst.next()){
                Employer employer = new Employer(rst.getString("Eid"), rst.getString("EName"), rst.getString("EAddress"), rst.getString("Email"), rst.getString("Tel_Number"),rst.getString("jobRole"));
                employerList.add(employer);
            }
            return employerList;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Optional<Employer> findByPk(String pk) throws ClassNotFoundException {
        try{
            ResultSet rst = DBUtil.executeQuery("SELECT * FROM Employer WHERE Eid=?", pk);
            if(rst.next()){
                return Optional.of(new Employer(rst.getString("Eid"), rst.getString("EName"), rst.getString("EAddress"),rst.getString("Email"),rst.getString("Tel_Number"),rst.getString("jobRole")));
            }
            return Optional.empty();
        } catch (SQLException e) {
            throw new RuntimeException("Failed to find the employer details");
        }
    }

    @Override
    public boolean existByPk(String pk) {
        return false;
    }

    @Override
    public long count() throws ClassNotFoundException {
        try{
            ResultSet rst = DBUtil.executeQuery("SELECT COUNT(Eid) AS count FROM Employer");
            rst.next();
            return rst.getInt(1);
        }catch (SQLException e){
            throw new RuntimeException(e);
        }
    }
}
