package dao.custom.impl;

import dao.custom.AttendanceDAO;
import dao.exception.CViolationException;
import dao.util.DBUtil;
import entity.Attendance;

import javax.persistence.EmbeddedId;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class AttendanceDAOImpl implements AttendanceDAO {

    private final Connection connection;

    public AttendanceDAOImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public Attendance save(Attendance attendance) throws CViolationException, SQLException, ClassNotFoundException {
        try{
            if(DBUtil.executeUpdate("INSERT INTO Attendance VALUES(?,?,?,?,?)",
                    attendance.getEid(),attendance.getAid(),attendance.getTimeIn(),attendance.getTimeOut(),attendance.getDate())){
                return attendance;
            }
            throw new SQLException("Failed to save the Attendance");
        }catch (SQLException e){
            throw new CViolationException(e);
        }
    }

    @Override
    public Attendance update(Attendance attendance) throws CViolationException, ClassNotFoundException {
        try {
            if (DBUtil.executeUpdate("UPDATE Attendance SET Aid=? ,Time_in=? ,Time_out=? , ADate=? WHERE Eid ",attendance.getAid(),attendance.getTimeIn(),attendance.getTimeOut(),attendance.getDate(),attendance.getEid())){
                return attendance;
            }
            throw new SQLException("Failed to update attendence");
        }catch (SQLException e){
            throw new CViolationException(e);
        }
    }

    @Override
    public void deleteByPk(String Eid) throws CViolationException, ClassNotFoundException {
        try {
            if (!DBUtil.executeUpdate("DELETE FROM Attendance WHERE Eid=?",Eid))
                throw new SQLException("Failed to delete the Atendance");
        }catch (SQLException e){
            throw new CViolationException(e);
        }
    }

    @Override
    public List<Attendance> findAll() throws ClassNotFoundException {
        try {
            ResultSet rst = DBUtil.executeQuery("SELECT * FROM Attendance");
            return getAttendanceList(rst);
        }catch (SQLException e){
            throw new RuntimeException("Failed to load the Attendance");
        }
    }

    private List<Attendance> getAttendanceList(ResultSet rst) {
        try {
            List<Attendance> attendanceList= new ArrayList<>();
            while (rst.next()){
                Attendance attendance = new Attendance(rst.getString("Eid"),rst.getString("Aid"),rst.getString("Time_in"),rst.getString("Time_out"),rst.getString("ADate"));
                attendanceList.add(attendance);
            }
            return attendanceList;
        }catch (SQLException e){
            throw new RuntimeException(e);
        }
    }

    @Override
    public Optional<Attendance> findByPk(String pk) throws ClassNotFoundException {
        try{
            ResultSet rst = DBUtil.executeQuery("SELECT * FROM Attendance WHERE Eid=?",pk);
            if (rst.next()) {
                return Optional.of(new Attendance(rst.getString("Eid"), rst.getString("Aid"), rst.getString("Time_in"), rst.getString("Time_out"), rst.getString("ADate")));

            }
            return Optional.empty();

        }catch (SQLException e){
            throw new RuntimeException("Failed to find the Atttendance");
        }
    }

    @Override
    public boolean existByPk(String pk) {
        return false;
    }

    @Override
    public long count() throws ClassNotFoundException {
        try{
            ResultSet rst = DBUtil.executeQuery("SELECT COUNT(Eid) AS count FROM Attendance");
            rst.next();
            return rst.getInt(1);
        }catch (SQLException e){
            throw new RuntimeException(e);
        }
    }
}
