package dao.custom.impl;

import dao.custom.SalaryDAO;
import dao.exception.CViolationException;
import dao.util.DBUtil;
import entity.Attendance;
import entity.Salary;
import org.hibernate.exception.ConstraintViolationException;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class SalaryDAOImpl implements SalaryDAO {
    private final Connection connection;

    public SalaryDAOImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public Salary save(Salary salary) throws CViolationException, ClassNotFoundException {
        try{
            if(DBUtil.executeUpdate("INSERT INTO Salary VALUES(?,?,?,?,?)",
                    salary.getSid(),salary.getEid(),salary.getSName(),salary.getAmount(),salary.getDescription())){
                return salary;
            }
            throw new SQLException("Failed to save the Salary");
        }catch (SQLException e){
            throw new CViolationException(e);
        }
    }

    @Override
    public Salary update(Salary salary) throws CViolationException, ClassNotFoundException {
        try {
            if (DBUtil.executeUpdate("UPDATE Salary SET Eid=? ,SName=? ,Amount=? , Description=? WHERE Sid ",salary.getEid(),salary.getSName(),salary.getAmount(),salary.getDescription(),salary.getSid())){
                return salary;
            }
            throw new SQLException("Failed to update attendence");
        }catch (SQLException e){
            throw new CViolationException(e);
        }
    }

    @Override
    public void deleteByPk(String Sid) throws CViolationException, ClassNotFoundException {
        try {
            if (!DBUtil.executeUpdate("DELETE FROM Salary WHERE Sid=?",Sid))
                throw new SQLException("Failed to delete the Salary");
        }catch (SQLException e){
            throw new CViolationException(e);
        }

    }

    @Override
    public List<Salary> findAll() throws ClassNotFoundException {
        try {
            ResultSet rst = DBUtil.executeQuery("SELECT * FROM Salary");
            return getSalaryList(rst);
        }catch (SQLException e){
            throw new RuntimeException("Failed to load the Salary");
        }    }

    private List<Salary> getSalaryList(ResultSet rst) {
        try {
            List<Salary> salaryList= new ArrayList<>();
            while (rst.next()){
                Salary salary = new Salary(rst.getString("Sid"),rst.getString("Eid"),rst.getString("SName"),rst.getString("Amount"),rst.getString("Description"));
                salaryList.add(salary);
            }
            return salaryList;
        }catch (SQLException e){
            throw new RuntimeException(e);
        }
    }

    @Override
    public Optional<Salary> findByPk(String pk) throws ClassNotFoundException {
        try{
            ResultSet rst = DBUtil.executeQuery("SELECT * FROM Salary WHERE Iid=?",pk);
            if (rst.next()) {
                return Optional.of(new Salary(rst.getString("Sid"),rst.getString("Eid"),rst.getString("SName"),rst.getString("Amount"),rst.getString("Description")));

            }
            return Optional.empty();

        }catch (SQLException e){
            throw new RuntimeException("Failed to find the Salary");
        }
    }

    @Override
    public boolean existByPk(String pk) {
        return false;
    }

    @Override
    public long count() throws ClassNotFoundException {
        try{
            ResultSet rst = DBUtil.executeQuery("SELECT COUNT(Sid) AS count FROM Salary");
            rst.next();
            return rst.getInt(1);
        }catch (SQLException e){
            throw new RuntimeException(e);
        }
    }
}
