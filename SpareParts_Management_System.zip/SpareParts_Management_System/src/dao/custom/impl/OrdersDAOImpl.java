package dao.custom.impl;

import dao.custom.OrdersDAO;
import dao.exception.CViolationException;
import entity.Orders;
import org.hibernate.exception.ConstraintViolationException;

import java.sql.Connection;
import java.util.List;
import java.util.Optional;

public class OrdersDAOImpl implements OrdersDAO {
    public OrdersDAOImpl(Connection connection) {
    }

    @Override
    public Orders save(Orders entity) throws CViolationException {
        return null;
    }

    @Override
    public Orders update(Orders entity) throws CViolationException {
        return null;
    }

    @Override
    public void deleteByPk(String pk) throws CViolationException {

    }

    @Override
    public List<Orders> findAll() {
        return null;
    }

    @Override
    public Optional<Orders> findByPk(String pk) {
        return Optional.empty();
    }

    @Override
    public boolean existByPk(String pk) {
        return false;
    }

    @Override
    public long count() {
        return 0;
    }
}
