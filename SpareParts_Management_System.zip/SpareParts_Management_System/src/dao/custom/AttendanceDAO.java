package dao.custom;

import dao.CrudDAO;
import entity.Attendance;

public interface AttendanceDAO extends CrudDAO<Attendance,String> {
}
