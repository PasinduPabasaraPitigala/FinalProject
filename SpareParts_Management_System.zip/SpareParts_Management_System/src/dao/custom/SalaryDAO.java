package dao.custom;

import dao.CrudDAO;
import entity.Salary;

public interface SalaryDAO extends CrudDAO<Salary,String> {
}
