package dao;

import entity.SuperEntity;
import org.hibernate.exception.ConstraintViolationException;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public interface CrudDAO<T extends SuperEntity,ID extends Serializable> extends SuperDAO {
    T save(T entity) throws ConstraintViolationException, SQLException, ClassNotFoundException;

    T update(T entity) throws ConstraintViolationException, ClassNotFoundException;

    void deleteByPk(ID pk) throws ConstraintViolationException, ClassNotFoundException;

    List<T> findAll() throws ClassNotFoundException;

    Optional<T> findByPk(ID pk) throws ClassNotFoundException;

    boolean existByPk(ID pk);

    long count() throws ClassNotFoundException;
}
