package dao.exception;

public class CViolationException extends RuntimeException {

    public CViolationException(){
    }
    public CViolationException(String message){
        super(message);
    }
    public CViolationException(String message, Throwable cause){
        super(message,cause);
    }
    public CViolationException(Throwable cause){super(cause);}

    public CViolationException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace){
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
