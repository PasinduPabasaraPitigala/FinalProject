package service.exception;

public class DuplicateException {
}
