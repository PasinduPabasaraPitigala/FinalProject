package service.exception;public class NotFoundException {
}
