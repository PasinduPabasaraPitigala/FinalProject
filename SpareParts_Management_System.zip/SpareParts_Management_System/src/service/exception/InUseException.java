package service.exception;

public class InUseException {
}
