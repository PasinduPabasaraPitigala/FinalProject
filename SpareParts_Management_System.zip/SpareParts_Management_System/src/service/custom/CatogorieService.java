package service.custom;

public interface CatogorieService {
}
