package service.custom;

public interface AttendanceService {
}
