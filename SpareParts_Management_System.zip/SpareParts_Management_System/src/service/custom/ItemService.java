package service.custom;

public interface ItemService {
}
