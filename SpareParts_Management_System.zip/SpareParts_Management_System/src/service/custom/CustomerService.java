package service.custom;

public interface CustomerService {
}
