package service.custom;

public interface OrdersService {
}
