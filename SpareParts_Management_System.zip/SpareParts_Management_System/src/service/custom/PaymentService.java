package service.custom;

public interface PaymentService {
}
