package service.custom;

public interface SalaryService {
}
