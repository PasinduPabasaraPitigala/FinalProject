package service.custom;

public interface EmployerService {
}
