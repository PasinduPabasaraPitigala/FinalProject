package service.custom;

public interface OrderDetailService {
}
