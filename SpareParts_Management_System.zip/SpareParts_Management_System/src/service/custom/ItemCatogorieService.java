package service.custom;

public interface ItemCatogorieService {
}
