package service.custom;

public interface SupplierDetailService {
}
