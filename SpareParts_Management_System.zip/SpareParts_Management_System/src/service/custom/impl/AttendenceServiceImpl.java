package service.custom.impl;

public class AttendenceServiceImpl {
}
