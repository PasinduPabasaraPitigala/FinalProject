package service.custom.impl;

public class SupplierDetailServiceImpl {
}
