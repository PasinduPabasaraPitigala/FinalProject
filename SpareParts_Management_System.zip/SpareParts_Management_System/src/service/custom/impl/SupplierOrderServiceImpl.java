package service.custom.impl;

public class SupplierOrderServiceImpl {
}
