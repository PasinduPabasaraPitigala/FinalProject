package service.custom.impl;

public class OrderDetailServiceImpl {
}
