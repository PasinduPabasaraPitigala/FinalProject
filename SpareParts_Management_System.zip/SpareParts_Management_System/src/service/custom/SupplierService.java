package service.custom;

public interface SupplierService {
}
