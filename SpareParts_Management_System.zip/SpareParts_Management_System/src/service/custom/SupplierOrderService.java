package service.custom;

public interface SupplierOrderService {
}
