package controller;

public class SupplierDetailFormController {
}
