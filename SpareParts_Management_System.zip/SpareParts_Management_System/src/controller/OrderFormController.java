package controller;

import com.jfoenix.controls.JFXTextField;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;

public class OrderFormController {
    public AnchorPane OrderContext;
    public Text orderId;
    public Text odescription;
    public Text odate;
    public JFXTextField oname;
    public Button save;
    public Button delete;
    public Text Ioid;
    public Button save1;
    public Button btnNext;
}
