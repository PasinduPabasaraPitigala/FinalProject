package controller;

public class StockManagerLoginFormController {
}
