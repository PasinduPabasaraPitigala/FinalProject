package controller;

import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;

public class OrderDetailFormController {
    public AnchorPane OrderContext;
    public Text orderId;
    public Button save1;
    public Button save11;
}
