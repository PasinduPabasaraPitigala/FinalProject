package controller;

import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;

public class SupplierOrderFormController {
    public AnchorPane SupplierContext;
    public Text odescription;
    public Text odate;
}
