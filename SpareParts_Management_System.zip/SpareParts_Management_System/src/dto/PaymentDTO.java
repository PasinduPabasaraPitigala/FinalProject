package dto;

public class PaymentDTO {
}
