package dto;

public class EmployerDTO {
}
