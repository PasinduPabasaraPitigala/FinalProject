package dto;

public class ItemCatogorieDTO {
}
