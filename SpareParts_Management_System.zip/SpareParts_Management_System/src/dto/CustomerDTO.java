package dto;

public class CustomerDTO {
}
