package dto;

public class SupplierOrderDTO {
}
