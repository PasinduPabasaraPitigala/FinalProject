package dto;

public class OrderDetailDTO {
}
