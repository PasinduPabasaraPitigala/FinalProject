package dto;

public class AttendanceDTO {
}
