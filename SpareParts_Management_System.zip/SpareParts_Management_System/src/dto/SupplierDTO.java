package dto;

public class SupplierDTO {
}
