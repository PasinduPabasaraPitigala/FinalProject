package dto;

public class SalaryDTO {
}
