package dto;

public class SupplierDetailDTO {
}
