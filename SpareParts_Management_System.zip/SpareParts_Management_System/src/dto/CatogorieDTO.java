package dto;

public class CatogorieDTO {
}
