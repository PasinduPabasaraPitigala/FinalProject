package dto;

public class ItemDTO {
}
